<?
	header("location:products.php");
?>