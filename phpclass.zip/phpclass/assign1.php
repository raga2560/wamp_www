<?php
define("COMPANY","IBM");

$str1 = "Rajesh is working with ";
$years = 10;



echo "$str1 ".COMPANY." for $years years";
?>