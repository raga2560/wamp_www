angular.module('myapp.controllers3', [])


;
   
	
