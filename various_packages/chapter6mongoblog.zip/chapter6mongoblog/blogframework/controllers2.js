angular.module('myapp.controllers2', [])

.controller('LoginRegistrationCtrl', function($rootScope, $scope,$location, $http,$state, LoginService) {
	   
	   
   })
   

   
.controller('TestCtrl', function($scope, $http) {
})

     
;
   
	
