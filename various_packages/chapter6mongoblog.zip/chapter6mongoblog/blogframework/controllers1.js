angular.module('myapp.controllers1', [])
				 



.controller('FrontCtrl', function($scope, $stateParams) {






})


;