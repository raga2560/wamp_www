<?php

$filename = "employees.json";
   $data = file_get_contents($filename);
   
   echo $data;
  
?>