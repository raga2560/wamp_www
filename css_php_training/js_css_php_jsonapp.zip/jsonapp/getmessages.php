<?php

$filename = "messages.json";
   $data = file_get_contents($filename);
   
   echo $data;
  
?>